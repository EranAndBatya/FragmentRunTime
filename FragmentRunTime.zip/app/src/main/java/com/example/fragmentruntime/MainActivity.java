package com.example.fragmentruntime;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {


    public static FragmentManager fragmentManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //fragmentManager- adding replace remove fragments
        fragmentManager = getSupportFragmentManager(); //get support to fragmentManager
        if(findViewById(R.id.fragment_main)!= null)
        {
            if(savedInstanceState!= null)//כל עוד האקטיביטי קיים
            {
                return;
            }
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();//start edit operation of fragments
            HomeFragment homeFragment = new HomeFragment();//create HomeFragment
            fragmentTransaction.add(R.id.fragment_main,homeFragment,null);//מוסיף את הריבוע שלhomeFragment לאקטיביטי
            fragmentTransaction.commit();//display
        }
    }
}
